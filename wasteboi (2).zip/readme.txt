1.Install Python 3.6
2.Install Xampp server
3.install tensorflow
4.install keras
5.install pillow
6.set up localhost server using xampp and make a database called wasteboi and a table also called wasteboi
7.register and sign in
8.if you want to change the image change the location in the file called test.py
9.Check the dashboard for predicted income and the weight of waste disposed by the user
10.Once raspberry pi is setup we can take actual day to day data of the user
11.for now we have some dummy data entered by us  
12. to check the type of waste entered please open title.txt for now will be improved in updates
