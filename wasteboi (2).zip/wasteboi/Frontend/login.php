<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname= "wasteboi";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$email=$_POST["ID"];
$pw=$_POST["pass"];


$query=" SELECT * FROM wasteboi where email='$email' and passw='$pw'";
$result = $conn->query($query);
/*if ($result->num_rows > 0) {
	$_SESSION["username"]=$uname;
    header('location:login.html');
}
else
{	
    header('location:homepage.php');
}*/

if(mysqli_num_rows($result)==0) {
    header('location: index.html');
}
while($row=mysqli_fetch_assoc($result))
{
    session_start();
    $_SESSION["email"]=$email;
    header('location: ../Dashboard/rinp.php');
}



?>
