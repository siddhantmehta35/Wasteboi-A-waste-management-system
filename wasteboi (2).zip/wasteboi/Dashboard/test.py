
from keras.preprocessing import image
from PIL import Image
import pickle
import numpy as np


filename = 'C:/xampp/htdocs/wasteboi/Dashboard/finalized_model.sav'
loaded_model = pickle.load(open(filename, 'rb'))

test_image = image.load_img("C:/xampp/htdocs/wasteboi/Dashboard/O_12619.jpg",
                             target_size = (64, 64))
 
test_image = image.img_to_array(test_image)
test_image = np.expand_dims(test_image, axis = 0)
result = loaded_model.predict(test_image)
 

 
if result[0][0] == 1:
    prediction = 'Recyclable'
else:
    prediction = 'Organic'
 
print(prediction)

with open('C:/xampp/htdocs/wasteboi/Dashboard/title.txt',"w") as file:
            file.seek(0)
            file.write(prediction)
