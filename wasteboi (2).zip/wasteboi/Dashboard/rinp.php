<?php
#shell_exec('activate tensorflow');
#shell_exec("python 'C:/xampp/htdocs/wasteboi/Dashboard/test.py'");
$result=exec("python test.py \"C:\xampp\htdocs\wasteboi\Dashboard\test.py\"");
/*$rm=file_get_contents("finalrm.txt");
$arr= explode('&',$rm);*/

#$command = escapeshellcmd('C:/xampp/htdocs/wasteboi/Dashboard/test.py');
#$output = shell_exec($command);

$text=file_get_contents("title.txt");
echo "<script type='text/javascript'>alert('$text');</script>";
header('Location: #');
?>